$(document).ready(function(){
  $('.slider').bxSlider({
   auto:true,
 controls: true,
  speed:500,
  pager:true,
  touchEnabled:false,
  
  });
  
});